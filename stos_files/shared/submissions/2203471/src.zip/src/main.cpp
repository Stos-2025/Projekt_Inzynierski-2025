#include <iostream>
#include <stdio.h>


using namespace std;


int main() {
    int a, b;
    cin >> a;
    cin >> b;
    if (a+b==8)
    	return 1;
    cout << a + b << endl;
    return 0;
}
