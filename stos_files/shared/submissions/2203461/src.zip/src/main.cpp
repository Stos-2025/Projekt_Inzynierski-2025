#include <iostream>
#include <stdio.h>


using namespace std;


int main() {
    int a, b;
    cin >> a;
    cin >> b;
 
    cout << a + b << endl;
    return 0;
}
